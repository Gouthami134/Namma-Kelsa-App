package com.example.namma_kelsa.data.model

import kotlinx.serialization.Serializable

@Serializable
data class WorkerProfile(
    val id: String = "",
    val name: String = "",
    val dailyRate: Double = 0.0,
    val location: String = "",
    val skills: List<String> = emptyList(),
    val isAvailable: Boolean = false,
    val profilePhotoUrl: String = "",
    val phoneNumber: String = "",
    val bio: String = "",
    val galleryUrls: List<String> = emptyList()
)
