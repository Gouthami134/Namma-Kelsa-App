package com.example.namma_kelsa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.adaptive.ExperimentalMaterial3AdaptiveApi
import androidx.compose.material3.adaptive.navigation3.ListDetailSceneStrategy
import androidx.compose.material3.adaptive.navigation3.rememberListDetailSceneStrategy
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation3.runtime.NavKey
import androidx.navigation3.runtime.entryProvider
import androidx.navigation3.runtime.rememberNavBackStack
import androidx.navigation3.ui.NavDisplay
import com.example.namma_kelsa.navigation.Route
import com.example.namma_kelsa.ui.discovery.WorkerDetailScreen
import com.example.namma_kelsa.ui.discovery.WorkerFeedScreen
import com.example.namma_kelsa.ui.profile.ProfileScreen
import com.example.namma_kelsa.ui.theme.NammaKelsaTheme

@OptIn(ExperimentalMaterial3AdaptiveApi::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NammaKelsaTheme {
                val backStack = rememberNavBackStack(Route.WorkerFeed as NavKey)
                val strategy = rememberListDetailSceneStrategy<NavKey>()
                
                NavigationSuiteScaffold(
                    navigationSuiteItems = {
                        item(
                            selected = backStack.lastOrNull() is Route.WorkerFeed || backStack.lastOrNull() is Route.WorkerDetail,
                            onClick = { 
                                backStack.clear()
                                backStack.add(Route.WorkerFeed)
                            },
                            icon = { Icon(Icons.Rounded.Home, contentDescription = "Home") },
                            label = { Text("Home") }
                        )
                        item(
                            selected = backStack.lastOrNull() is Route.MyProfile,
                            onClick = { 
                                backStack.clear()
                                backStack.add(Route.MyProfile)
                            },
                            icon = { Icon(Icons.Rounded.AccountCircle, contentDescription = "Profile") },
                            label = { Text("Profile") }
                        )
                    }
                ) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize()
                    ) { innerPadding ->
                        NavDisplay(
                            backStack = backStack,
                            modifier = Modifier.padding(innerPadding),
                            sceneStrategies = listOf(strategy),
                            onBack = { backStack.removeLastOrNull() },
                            entryProvider = entryProvider {
                                entry<Route.WorkerFeed>(
                                    metadata = ListDetailSceneStrategy.listPane(
                                        detailPlaceholder = {
                                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                                Text("Select a worker to see details")
                                            }
                                        }
                                    )
                                ) {
                                    WorkerFeedScreen(
                                        onWorkerClick = { id -> backStack.add(Route.WorkerDetail(id)) }
                                    )
                                }
                                
                                entry<Route.WorkerDetail>(
                                    metadata = ListDetailSceneStrategy.detailPane()
                                ) { key: Route.WorkerDetail ->
                                    WorkerDetailScreen(
                                        workerId = key.workerId,
                                        onBack = { backStack.removeLastOrNull() }
                                    )
                                }
                                
                                entry<Route.MyProfile> {
                                    // Use a valid mock ID for the "My Profile" demonstration
                                    ProfileScreen(workerId = "1")
                                }
                                
                                entry<Route.CreateIdentity> {
                                    ProfileScreen()
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
