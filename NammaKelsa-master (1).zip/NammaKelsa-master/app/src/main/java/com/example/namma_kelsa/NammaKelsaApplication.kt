package com.example.namma_kelsa

import android.app.Application
import com.google.firebase.FirebaseApp

class NammaKelsaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Firebase initialization
        // Note: This requires google-services.json to be present in the app/ folder.
        // If it's missing, the app might crash or fail to build depending on the plugin setup.
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
