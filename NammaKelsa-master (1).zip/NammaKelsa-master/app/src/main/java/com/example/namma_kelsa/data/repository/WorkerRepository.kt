package com.example.namma_kelsa.data.repository

import android.net.Uri
import com.example.namma_kelsa.data.model.WorkerProfile
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

interface WorkerRepository {
    fun getWorkerProfile(workerId: String): Flow<WorkerProfile?>
    suspend fun saveWorkerProfile(profile: WorkerProfile)
    suspend fun updateAvailability(workerId: String, isAvailable: Boolean)
    suspend fun uploadProfilePhoto(workerId: String, imageUri: Uri): String
    suspend fun uploadGalleryPhoto(workerId: String, imageUri: Uri): String
    fun getAllWorkers(skillFilter: String? = null): Flow<List<WorkerProfile>>
}

class FirestoreWorkerRepository : WorkerRepository {
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val storage by lazy { FirebaseStorage.getInstance() }
    private val workersCollection by lazy { firestore.collection("workers") }

    override fun getWorkerProfile(workerId: String): Flow<WorkerProfile?> = callbackFlow {
        val subscription = workersCollection.document(workerId)
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null && snapshot.exists()) {
                    try {
                        val profile = snapshot.toObject(WorkerProfile::class.java)
                        trySend(profile?.copy(id = snapshot.id))
                    } catch (e: Exception) {
                        trySend(null)
                    }
                } else {
                    trySend(null)
                }
            }
        awaitClose { subscription.remove() }
    }

    override suspend fun saveWorkerProfile(profile: WorkerProfile) {
        if (profile.id.isEmpty()) {
            workersCollection.add(profile).await()
        } else {
            workersCollection.document(profile.id).set(profile).await()
        }
    }

    override suspend fun updateAvailability(workerId: String, isAvailable: Boolean) {
        workersCollection.document(workerId).update("isAvailable", isAvailable).await()
    }

    override suspend fun uploadProfilePhoto(workerId: String, imageUri: Uri): String {
        val ref = storage.reference.child("profile_photos/$workerId.jpg")
        ref.putFile(imageUri).await()
        return ref.downloadUrl.await().toString()
    }

    override suspend fun uploadGalleryPhoto(workerId: String, imageUri: Uri): String {
        val fileName = System.currentTimeMillis().toString()
        val ref = storage.reference.child("work_gallery/$workerId/$fileName.jpg")
        ref.putFile(imageUri).await()
        return ref.downloadUrl.await().toString()
    }

    override fun getAllWorkers(skillFilter: String?): Flow<List<WorkerProfile>> = callbackFlow {
        val query = if (skillFilter != null) {
            workersCollection.whereArrayContains("skills", skillFilter)
        } else {
            workersCollection
        }

        val subscription = query.addSnapshotListener { snapshot, _ ->
            if (snapshot != null) {
                val workers = snapshot.documents.mapNotNull { doc ->
                    doc.toObject(WorkerProfile::class.java)?.copy(id = doc.id)
                }
                trySend(workers)
            }
        }
        awaitClose { subscription.remove() }
    }
}
