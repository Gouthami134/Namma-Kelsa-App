package com.example.namma_kelsa.navigation

import androidx.navigation3.runtime.NavKey
import kotlinx.serialization.Serializable

@Serializable
sealed interface Route : NavKey {
    @Serializable
    data object WorkerFeed : Route

    @Serializable
    data class WorkerDetail(val workerId: String) : Route

    @Serializable
    data object MyProfile : Route

    @Serializable
    data object CreateIdentity : Route
}
