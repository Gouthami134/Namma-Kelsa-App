package com.example.namma_kelsa.ui.theme

import androidx.compose.ui.graphics.Color

// Vibrant Energetic Palette
val PrimaryLight = Color(0xFFD84315) // Deep Orange 800
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFFFDBD1)
val OnPrimaryContainerLight = Color(0xFF3B0900)

val SecondaryLight = Color(0xFF77574E)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFFDBD1)
val OnSecondaryContainerLight = Color(0xFF2C150F)

val TertiaryLight = Color(0xFF2E7D32) // Green 800
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFB0F4A5)
val OnTertiaryContainerLight = Color(0xFF002204)

val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)

val BackgroundLight = Color(0xFFFFF8F6)
val OnBackgroundLight = Color(0xFF231A17)
val SurfaceLight = Color(0xFFFFF8F6)
val OnSurfaceLight = Color(0xFF231A17)

// Dark Palette
val PrimaryDark = Color(0xFFFFB4A1)
val OnPrimaryDark = Color(0xFF5E1700)
val PrimaryContainerDark = Color(0xFF8D2C0D)
val OnPrimaryContainerDark = Color(0xFFFFDBD1)

val SecondaryDark = Color(0xFFE7BDB2)
val OnSecondaryDark = Color(0xFF442A22)
val SecondaryContainerDark = Color(0xFF5D4037)
val OnSecondaryContainerDark = Color(0xFFFFDBD1)

val TertiaryDark = Color(0xFF95D88B)
val OnTertiaryDark = Color(0xFF00390A)
val TertiaryContainerDark = Color(0xFF0D531B)
val OnTertiaryContainerDark = Color(0xFFB0F4A5)

val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)
val ErrorContainerDark = Color(0xFF93000A)
val OnErrorContainerDark = Color(0xFFFFDAD6)

val BackgroundDark = Color(0xFF1A110F)
val OnBackgroundDark = Color(0xFFF1DFDA)
val SurfaceDark = Color(0xFF1A110F)
val OnSurfaceDark = Color(0xFFF1DFDA)
