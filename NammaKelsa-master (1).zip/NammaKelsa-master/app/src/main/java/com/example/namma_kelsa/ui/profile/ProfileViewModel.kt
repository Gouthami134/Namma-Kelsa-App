package com.example.namma_kelsa.ui.profile

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.namma_kelsa.data.model.WorkerProfile
import com.example.namma_kelsa.data.repository.WorkerRepository
import com.example.namma_kelsa.di.ServiceLocator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ProfileViewModel(
    private val repository: WorkerRepository = ServiceLocator.workerRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ProfileUiState>(ProfileUiState.Loading)
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    private val _profile = MutableStateFlow(WorkerProfile())
    val profile: StateFlow<WorkerProfile> = _profile.asStateFlow()

    fun loadProfile(workerId: String) {
        viewModelScope.launch {
            repository.getWorkerProfile(workerId).collectLatest { loadedProfile ->
                if (loadedProfile != null) {
                    _profile.value = loadedProfile
                    _uiState.value = ProfileUiState.Success
                } else {
                    _uiState.value = ProfileUiState.NewProfile
                }
            }
        }
    }

    fun updateName(name: String) {
        _profile.value = _profile.value.copy(name = name)
    }

    fun updateDailyRate(rate: String) {
        val dailyRate = rate.toDoubleOrNull() ?: 0.0
        _profile.value = _profile.value.copy(dailyRate = dailyRate)
    }

    fun updateLocation(location: String) {
        _profile.value = _profile.value.copy(location = location)
    }

    fun updatePhoneNumber(phone: String) {
        _profile.value = _profile.value.copy(phoneNumber = phone)
    }

    fun toggleSkill(skill: String) {
        val currentSkills = _profile.value.skills.toMutableList()
        if (currentSkills.contains(skill)) {
            currentSkills.remove(skill)
        } else {
            currentSkills.add(skill)
        }
        _profile.value = _profile.value.copy(skills = currentSkills)
    }

    fun updateAvailability(isAvailable: Boolean) {
        _profile.value = _profile.value.copy(isAvailable = isAvailable)
        val workerId = _profile.value.id
        if (workerId.isNotEmpty()) {
            viewModelScope.launch {
                repository.updateAvailability(workerId, isAvailable)
            }
        }
    }

    fun saveProfile() {
        viewModelScope.launch {
            _uiState.value = ProfileUiState.Loading
            try {
                repository.saveWorkerProfile(_profile.value)
                _uiState.value = ProfileUiState.Success
            } catch (e: Exception) {
                _uiState.value = ProfileUiState.Error(e.message ?: "Unknown error")
            }
        }
    }

    fun uploadPhoto(uri: Uri) {
        val workerId = _profile.value.id
        if (workerId.isEmpty()) return
        
        viewModelScope.launch {
            try {
                val url = repository.uploadProfilePhoto(workerId, uri)
                _profile.value = _profile.value.copy(profilePhotoUrl = url)
                repository.saveWorkerProfile(_profile.value)
            } catch (e: Exception) {
                // Handle error
            }
        }
    }

    fun uploadGalleryPhoto(uri: Uri) {
        val workerId = _profile.value.id
        if (workerId.isEmpty()) return
        
        viewModelScope.launch {
            try {
                val url = repository.uploadGalleryPhoto(workerId, uri)
                val currentGallery = _profile.value.galleryUrls.toMutableList()
                currentGallery.add(url)
                _profile.value = _profile.value.copy(galleryUrls = currentGallery)
                repository.saveWorkerProfile(_profile.value)
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
}

sealed interface ProfileUiState {
    data object Loading : ProfileUiState
    data object Success : ProfileUiState
    data object NewProfile : ProfileUiState
    data class Error(val message: String) : ProfileUiState
}
