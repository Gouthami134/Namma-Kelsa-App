package com.example.namma_kelsa.di

import com.example.namma_kelsa.data.repository.FirestoreWorkerRepository
import com.example.namma_kelsa.data.repository.MockWorkerRepository
import com.example.namma_kelsa.data.repository.WorkerRepository
import com.example.namma_kelsa.BuildConfig

object ServiceLocator {
    // Forcing mock for now to prevent crashes when google-services.json is missing
    private val useMock = true 

    val workerRepository: WorkerRepository by lazy {
        if (useMock) {
            MockWorkerRepository()
        } else {
            FirestoreWorkerRepository()
        }
    }
}
