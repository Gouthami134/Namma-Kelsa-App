package com.example.namma_kelsa.ui.discovery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.namma_kelsa.data.model.WorkerProfile
import com.example.namma_kelsa.data.repository.WorkerRepository
import com.example.namma_kelsa.di.ServiceLocator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DiscoveryViewModel(
    private val repository: WorkerRepository = ServiceLocator.workerRepository
) : ViewModel() {

    private val _workers = MutableStateFlow<List<WorkerProfile>>(emptyList())
    val workers: StateFlow<List<WorkerProfile>> = _workers.asStateFlow()

    private val _selectedSkill = MutableStateFlow<String?>(null)
    val selectedSkill: StateFlow<String?> = _selectedSkill.asStateFlow()

    init {
        loadWorkers()
    }

    fun setSkillFilter(skill: String?) {
        _selectedSkill.value = if (_selectedSkill.value == skill) null else skill
        loadWorkers()
    }

    private fun loadWorkers() {
        viewModelScope.launch {
            repository.getAllWorkers(_selectedSkill.value).collectLatest {
                _workers.value = it
            }
        }
    }
}
