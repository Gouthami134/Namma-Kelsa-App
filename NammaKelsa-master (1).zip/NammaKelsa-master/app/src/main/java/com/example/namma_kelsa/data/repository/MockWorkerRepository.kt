package com.example.namma_kelsa.data.repository

import android.net.Uri
import com.example.namma_kelsa.data.model.WorkerProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map

class MockWorkerRepository : WorkerRepository {
    private val mockWorkers = MutableStateFlow(listOf(
        WorkerProfile(
            id = "1",
            name = "Ravi Kumar",
            dailyRate = 800.0,
            location = "Indiranagar, Bangalore",
            skills = listOf("Painter", "Gardener"),
            isAvailable = true,
            phoneNumber = "9876543210",
            profilePhotoUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=400",
                "https://images.unsplash.com/photo-1562591176-3293399991cb?w=400"
            )
        ),
        WorkerProfile(
            id = "2",
            name = "Lakshmi M.",
            dailyRate = 600.0,
            location = "Koramangala, Bangalore",
            skills = listOf("Cleaner", "Gardener"),
            isAvailable = false,
            phoneNumber = "9123456789",
            profilePhotoUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=400"
            )
        ),
        WorkerProfile(
            id = "3",
            name = "Arjun Singh",
            dailyRate = 1200.0,
            location = "HSR Layout, Bangalore",
            skills = listOf("Electrician", "Plumber"),
            isAvailable = true,
            phoneNumber = "9988776655",
            profilePhotoUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400",
            galleryUrls = listOf(
                "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400",
                "https://images.unsplash.com/photo-1558223108-630d9d21c796?w=400"
            )
        )
    ))

    override fun getWorkerProfile(workerId: String): Flow<WorkerProfile?> {
        return mockWorkers.map { list -> list.find { it.id == workerId } }
    }

    override suspend fun saveWorkerProfile(profile: WorkerProfile) {
        val currentList = mockWorkers.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == profile.id }
        if (index != -1) {
            currentList[index] = profile
        } else {
            currentList.add(profile.copy(id = (currentList.size + 1).toString()))
        }
        mockWorkers.value = currentList
    }

    override suspend fun updateAvailability(workerId: String, isAvailable: Boolean) {
        val currentList = mockWorkers.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == workerId }
        if (index != -1) {
            currentList[index] = currentList[index].copy(isAvailable = isAvailable)
            mockWorkers.value = currentList
        }
    }

    override suspend fun uploadProfilePhoto(workerId: String, imageUri: Uri): String {
        return imageUri.toString() // Just return URI as string in mock
    }

    override suspend fun uploadGalleryPhoto(workerId: String, imageUri: Uri): String {
        return imageUri.toString()
    }

    override fun getAllWorkers(skillFilter: String?): Flow<List<WorkerProfile>> {
        return if (skillFilter == null) {
            mockWorkers
        } else {
            mockWorkers.map { list -> list.filter { it.skills.contains(skillFilter) } }
        }
    }
}
