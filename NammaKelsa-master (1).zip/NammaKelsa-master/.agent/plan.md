# Project Plan

Namma-Kelsa is a "Dignity-First" labor marketplace. It is a local directory where skilled workers create a "Digital Identity." It doesn't just list phone numbers; it shows "Badges of Skill" and "Verified Photos" of their past work. It allows a local homeowner to find a "Painter in 2kms" and hire them directly.

Technical Implementation & Hints:
- Database: Firebase Firestore to allow real-time availability updates.
- Storage: Store worker profile photos and work samples.
- UI: Use ChipGroup (or Compose equivalent) for selecting skills.

Success Criteria:
- The "Availability Switch" must update the search results instantly.
- The worker profile must have a "Call" button that works with the phone's dialer.
- The UI must be simple enough for a worker to manage their own profile.

## Project Brief

# Project Brief: Namma-Kelsa

## Features
* **Digital Worker Identity:** Skilled workers can create a professional profile featuring a profile photo, skill category (using Material 3 Chips), daily rate, and location to build digital trust.
* **Real-Time Availability Toggle:** A simple "Available for Work Today" switch that workers can toggle to instantly update their visibility in customer search results.
* **Visual Work Gallery:** A portfolio section allowing workers to upload and showcase photos of their "Recent Work" to demonstrate skill and quality.
* **Skill-Based Discovery:** A customer-facing search interface that allows homeowners to filter workers by specific skills and proximity.
* **One-Tap Contact:** Direct integration with the device dialer via a "Call" button on worker profiles, facilitating direct hiring without middlemen.

## High-Level Technical Stack
* **Language:** Kotlin
* **UI Framework:** Jetpack Compose (Material Design 3)
* **Navigation:** **Jetpack Navigation 3** (State-driven)
* **Adaptive Strategy:** **Compose Material Adaptive** library for responsive layouts across different screen sizes.
* **Asynchronous Logic:** Kotlin Coroutines & Flow
* **Backend & Persistence:** Firebase Firestore (for real-time availability updates) and Firebase Storage (for worker photos and gallery images).
* **Image Loading:** Coil for efficient image rendering.

## Implementation Steps

### Task_1_Foundation: Initialize the project foundation including Firebase (Firestore/Storage) integration, Material 3 theme with a vibrant energetic color scheme, edge-to-edge support, and Jetpack Navigation 3 setup.
- **Status:** COMPLETED
- **Updates:** Initialized the project with Firebase (Firestore/Storage) dependencies. Implemented a vibrant Material 3 theme with Deep Orange and Amber color schemes. Enabled Edge-to-Edge display. Established the Navigation 3 structure with serializable routes (WorkerFeed, WorkerDetail, MyProfile, CreateIdentity). Updated compileSdk to 37. Note: google-services plugin is currently commented out in build.gradle.kts due to missing google-services.json, but the app builds and runs.
- **Acceptance Criteria:**
  - Project builds successfully
  - Firebase is initialized in the app
  - Material 3 theme with dark/light modes and vibrant colors is implemented
  - Edge-to-edge display is enabled
  - Navigation 3 structure is established

### Task_2_Worker_Identity: Implement the Worker Profile management features: profile creation/editing with name, daily rate, location, skill selection (M3 Chips), and the real-time Availability Toggle linked to Firestore.
- **Status:** COMPLETED
- **Updates:** Implemented WorkerProfile data model, WorkerRepository for Firestore/Storage operations, and ProfileViewModel. Created a comprehensive ProfileScreen UI with profile photo upload, real-time availability toggle, and skill selection using Material 3 Chips. Integrated these into the Navigation 3 backstack. Verified that the app builds with these changes.
- **Acceptance Criteria:**
  - Worker can save/edit profile details to Firestore
  - Skill chips allow selection of labor categories
  - Availability switch updates worker status in real-time in Firestore
  - Profile photo can be uploaded to Firebase Storage and displayed using Coil

### Task_3_Discovery_and_Portfolio: Develop the Visual Work Gallery for workers and the Skill-Based Discovery interface for customers, including worker search/filtering and direct dialer integration.
- **Status:** COMPLETED
- **Updates:** Implemented the Visual Work Gallery allowing workers to upload and view photos of their work. Created the Skill-Based Discovery interface (WorkerFeedScreen) with filtering capabilities. Developed the WorkerDetailScreen showing the gallery and profile info. Integrated the "Call" button with the device dialer. All features are wired into the Navigation 3 system.
- **Acceptance Criteria:**
  - Workers can upload and view gallery photos in their portfolio via Firebase Storage
  - Customers can search/filter workers by skill and view availability status
  - Worker detail screen shows gallery and profile info
  - Call button opens the device dialer with the worker's number
- **Duration:** N/A

### Task_4_Adaptive_Polish_Verification: Apply Compose Material Adaptive layouts for responsiveness, create an adaptive app icon, and perform a final 'Run and Verify' to ensure stability and requirement alignment.
- **Status:** IN_PROGRESS
- **Acceptance Criteria:**
  - UI uses adaptive layouts (e.g., List-Detail) for different screen sizes
  - Adaptive app icon matching the app's core function is implemented
  - App does not crash during standard flows
  - All existing tests pass and build is successful
  - Final UI verification confirms alignment with energetic Material 3 aesthetic
- **StartTime:** 2026-05-14 21:29:56 IST

